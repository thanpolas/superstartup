-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 05, 2012 at 05:27 PM
-- Server version: 5.1.44
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `corefw`
--

-- --------------------------------------------------------

--
-- Table structure for table `daily_activity`
--

CREATE TABLE IF NOT EXISTS `daily_activity` (
  `actId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `day` date NOT NULL,
  `new_visitors` int(10) unsigned NOT NULL,
  `new_users` int(10) unsigned NOT NULL,
  `conversion` tinyint(3) unsigned NOT NULL,
  `total_frames` int(10) unsigned NOT NULL,
  `total_comments` int(10) unsigned NOT NULL,
  `fb_shares` int(10) unsigned NOT NULL,
  `fb_likes` int(10) unsigned NOT NULL,
  `tweets` int(10) unsigned NOT NULL,
  PRIMARY KEY (`actId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `metrics_campaigns`
--

CREATE TABLE IF NOT EXISTS `metrics_campaigns` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `permId` bigint(20) unsigned DEFAULT NULL,
  `source` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `campaign` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `version` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `userId` bigint(20) NOT NULL DEFAULT '0',
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- Table structure for table `metrics_counters`
--

CREATE TABLE IF NOT EXISTS `metrics_counters` (
  `metricsCountersId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) unsigned NOT NULL,
  `permId` bigint(20) unsigned DEFAULT NULL,
  `nickname` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `createDateTime` datetime NOT NULL,
  `userIPaddress` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `category` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `action` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `label` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `value` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `value_2` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `value_3` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `value_4` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`metricsCountersId`),
  KEY `userId` (`userId`),
  KEY `category` (`category`),
  KEY `action` (`action`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1058 ;

-- --------------------------------------------------------

--
-- Table structure for table `metrics_flash`
--

CREATE TABLE IF NOT EXISTS `metrics_flash` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) unsigned NOT NULL,
  `permId` bigint(20) unsigned DEFAULT NULL,
  `sessionId` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `createDatetime` datetime NOT NULL,
  `isRemembered` int(11) NOT NULL DEFAULT '0',
  `openModal` int(11) NOT NULL DEFAULT '0',
  `clickAllow` int(11) NOT NULL DEFAULT '0',
  `clickDeny` int(11) NOT NULL DEFAULT '0',
  `camInited` int(11) NOT NULL DEFAULT '0',
  `firstTimeout` int(11) NOT NULL DEFAULT '0',
  `secondTimeout` int(11) NOT NULL DEFAULT '0',
  `cameraLive` int(11) NOT NULL DEFAULT '0',
  `platform` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `mobile` varchar(40) COLLATE latin1_general_ci DEFAULT NULL,
  `browser` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `browserVersion` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `hasFlash` tinyint(1) DEFAULT NULL,
  `FlashVersion` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `agent_string` varchar(250) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  KEY `sessionId` (`sessionId`),
  KEY `createDatetime` (`createDatetime`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=140 ;

-- --------------------------------------------------------

--
-- Table structure for table `metrics_permcook`
--

CREATE TABLE IF NOT EXISTS `metrics_permcook` (
  `permId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `createDatetime` datetime DEFAULT NULL,
  `lastSeenDatetime` datetime DEFAULT NULL,
  `visitCounter` int(11) DEFAULT NULL,
  `referrer` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstIP` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userId` bigint(20) unsigned DEFAULT NULL,
  `isNewUser` tinyint(1) DEFAULT NULL,
  `userDatetime` datetime DEFAULT NULL,
  `platform` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `browserVersion` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `landPage` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userAgent` text COLLATE utf8_unicode_ci,
  `metadata` text COLLATE utf8_unicode_ci COMMENT 'JSON string',
  `campaign` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`permId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=39 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `userId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `password` varchar(300) COLLATE latin1_general_ci DEFAULT NULL,
  `real_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `disabled_reason` text COLLATE latin1_general_ci,
  `date_added` datetime NOT NULL,
  `hasExtSource` tinyint(4) NOT NULL DEFAULT '1',
  `authSourceId` int(11) NOT NULL COMMENT '5=FB, 6=TW',
  `http_referrer` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `campaignSource` varchar(40) COLLATE latin1_general_ci DEFAULT NULL,
  `loginCounter` int(11) NOT NULL DEFAULT '0',
  `new_message` int(11) NOT NULL DEFAULT '0',
  `new_notifications` int(11) DEFAULT '0',
  `new_notifications_data` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `settings_data` text COLLATE latin1_general_ci,
  `metadata` text COLLATE latin1_general_ci,
  `permId` bigint(20) unsigned DEFAULT NULL,
  `campaign` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `ab_test` varchar(40) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`userId`),
  KEY `nickname` (`nickname`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=25 ;

-- --------------------------------------------------------

--
-- Table structure for table `users_info`
--

CREATE TABLE IF NOT EXISTS `users_info` (
  `userId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `web` varchar(200) CHARACTER SET ascii DEFAULT NULL,
  `bio` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastUpdate` datetime NOT NULL,
  `userEditCount` int(11) NOT NULL DEFAULT '0' COMMENT 'How many times user edited',
  PRIMARY KEY (`userId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

-- --------------------------------------------------------

--
-- Table structure for table `users_message`
--

CREATE TABLE IF NOT EXISTS `users_message` (
  `usersMessageId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `from_userId` bigint(20) unsigned NOT NULL,
  `to_userId` bigint(20) unsigned NOT NULL,
  `createDatetime` datetime NOT NULL,
  `message` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `del_from` tinyint(1) NOT NULL DEFAULT '0',
  `del_from_datetime` datetime DEFAULT NULL,
  `del_to` tinyint(1) NOT NULL DEFAULT '0',
  `del_to_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`usersMessageId`),
  KEY `from_userId` (`from_userId`),
  KEY `to_userId` (`to_userId`),
  KEY `del_from` (`del_from`,`del_to`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=43 ;

-- --------------------------------------------------------

--
-- Table structure for table `users_notify`
--

CREATE TABLE IF NOT EXISTS `users_notify` (
  `userId` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `userId` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users_notify_static`
--

CREATE TABLE IF NOT EXISTS `users_notify_static` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) NOT NULL,
  `createDatetime` datetime NOT NULL,
  `type` varchar(20) CHARACTER SET ascii NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  KEY `createDatetime` (`createDatetime`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=80 ;

-- --------------------------------------------------------

--
-- Table structure for table `users_source`
--

CREATE TABLE IF NOT EXISTS `users_source` (
  `usersSourceId` bigint(20) NOT NULL AUTO_INCREMENT,
  `authSourceId` int(20) unsigned NOT NULL,
  `userId` bigint(20) unsigned NOT NULL,
  `extUserId` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `extVerified` tinyint(1) NOT NULL,
  `extUrl` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `extUsername` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `extProfileImageUrl` varchar(300) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `createDatetime` datetime NOT NULL,
  `oAuthToken` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oAuthTokenSecret` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `extDataObject` longtext COLLATE utf8_unicode_ci COMMENT 'PHP Serialized field',
  PRIMARY KEY (`usersSourceId`),
  KEY `userId` (`userId`),
  KEY `extUserId` (`extUserId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;
